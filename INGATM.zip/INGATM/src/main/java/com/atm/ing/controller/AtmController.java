package com.atm.ing.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.atm.ing.entity.AtmInfo;
import com.atm.ing.responsePattern.AtmResponsePattern;
import com.atm.ing.service.AtmService;
import com.atm.ing.vo.AtmInfoVO;



@RequestMapping(value="/atms")
@RestController
public class AtmController {
	@Autowired
	AtmService atmService;
	
	
	
	@GetMapping(value="/all")
	private List<AtmInfoVO> listAtms(){
		
		return atmService.getAllAtms();
	}
	
	
	@PostMapping(value="/addAtm/{id}")
	private ResponseEntity<AtmResponsePattern> saveBrands(@RequestBody AtmInfoVO atmvo ,@PathVariable  Long id){

		System.out.println(atmvo);
		System.out.println(id);
		AtmResponsePattern arsp = atmService.addAtm(atmvo, id);
		return new ResponseEntity<AtmResponsePattern>(arsp, HttpStatus.OK);
		
		
	}
	
	@GetMapping(value="/getAtmList/{id}")
	public List<AtmInfo> getAtmByCity(@PathVariable Long id){

	return atmService.getAtmByCity(id);
	}

}
