package com.atm.ing.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.atm.ing.entity.AtmInfo;


@Repository
public interface AtmRepository extends JpaRepository<AtmInfo,Long>{

	public List<AtmInfo> findBycities_cityId(@Param("cityId") Long cityid);
}
