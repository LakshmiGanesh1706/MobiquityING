package com.atm.ing.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.atm.ing.entity.CityInfo;

@Repository
public interface CityRepository extends JpaRepository<CityInfo,Long>{

}





