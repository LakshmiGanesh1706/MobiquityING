package com.atm.ing.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.atm.ing.responsePattern.CityResponsePattern;
import com.atm.ing.service.CityService;
import com.atm.ing.vo.CityInfoVO;



@RequestMapping(value="/city")
@RestController
public class CityController {

	@Autowired
	 CityService cityService;	
	
	
	@GetMapping(value="/all")
	public List<CityInfoVO> getAllCities(){
		
		return cityService.getCities();
	}


	@PostMapping(value="/saveCity")
	private ResponseEntity<CityResponsePattern> saveCity(@RequestBody CityInfoVO c){
		
		
		CityResponsePattern crp = cityService.citypat(c);
		return new ResponseEntity<CityResponsePattern>(crp, HttpStatus.OK);
		
		
	}	
}
