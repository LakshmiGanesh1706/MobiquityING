package com.atm.ing.mapper;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Component;

import com.atm.ing.entity.AtmInfo;
import com.atm.ing.vo.AtmInfoVO;


@Component
public class AtmInfoMapper {

	public void fromAtmToAtmVO(AtmInfo atm, AtmInfoVO atmvo) {
        try {
            BeanUtils.copyProperties(atmvo, atm);
        } catch (Exception e) {

        }
    }

 public void fromAtmVOToAtm(AtmInfoVO atmvo,AtmInfo atm ) {
        try {
            BeanUtils.copyProperties( atm,atmvo);
        } catch (Exception e) {

        }
    }
	
}
