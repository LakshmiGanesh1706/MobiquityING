package com.atm.ing.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity

@Table(name="atm")
public class AtmInfo {
	 @Id

     @Column(name="atm_id")
	private Long atmId;
	 @Column(name="atm_branch")
	private String atmBranch;
	 @Column(name="atm_address")
	private String atmAddress;
	
	 
	 @ManyToOne()

     @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})

     @JsonIgnore

     //@JsonView(brand.class)

     @JoinColumn(name = "city_id")

     private CityInfo cities;
	public Long getAtmId() {
		return atmId;
	}
	public void setAtmId(Long atmId) {
		this.atmId = atmId;
	}
	public String getAtmBranch() {
		return atmBranch;
	}
	public void setAtmBranch(String atmBranch) {
		this.atmBranch = atmBranch;
	}
	public String getAtmAddress() {
		return atmAddress;
	}
	public void setAtmAddress(String atmAddress) {
		this.atmAddress = atmAddress;
	}
	public CityInfo getCities() {
		return cities;
	}
	public void setCities(CityInfo cities) {
		this.cities = cities;
	}
	
	
	
}
