package com.atm.ing.service;

import java.util.List;

import com.atm.ing.responsePattern.CityResponsePattern;
import com.atm.ing.vo.CityInfoVO;


public interface CityService {

public List<CityInfoVO> getCities();
	
	public CityResponsePattern citypat(CityInfoVO c);
}
