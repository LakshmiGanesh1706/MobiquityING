package com.atm.ing.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atm.ing.Repository.AtmRepository;
import com.atm.ing.Repository.CityRepository;
import com.atm.ing.entity.AtmInfo;
import com.atm.ing.entity.CityInfo;
import com.atm.ing.mapper.AtmInfoMapper;
import com.atm.ing.responsePattern.AtmResponsePattern;
import com.atm.ing.vo.AtmInfoVO;


@Service
public class AtmServiceImpl implements AtmService{

	@Autowired

	AtmRepository atmRepo;

	 

	@Autowired

	CityRepository cityRepo;

	 

	@Autowired

	AtmInfoMapper atmMapper;	
	
	
	
	@Override
	public List<AtmInfoVO> getAllAtms() {

        List<AtmInfoVO> atmVOs = new ArrayList<>();

        List<AtmInfo> atms = atmRepo.findAll();

        atms.forEach(atm ->{

        	AtmInfoVO atmvo = new AtmInfoVO();

        	atmMapper.fromAtmToAtmVO(atm, atmvo);

        	atmVOs.add(atmvo);

        });

       

        return atmVOs;


	}

	@Override
	public AtmResponsePattern addAtm(AtmInfoVO atmVo, Long id) {
		 if(atmVo != null && id != null) {

             

             AtmResponsePattern arp = new AtmResponsePattern();

            CityInfo city = cityRepo.getOne(id);
           // Optional<CityInfo> city = cityRepo.findById(id);
             if(city != null) {
AtmInfo atminfo = new AtmInfo();
                            Long autoAtmId = System.currentTimeMillis();
                            atmVo.setAtmId(autoAtmId);
                            atmVo.setCities(city);
                            System.out.println(atmVo);
                            atmMapper.fromAtmVOToAtm(atmVo, atminfo);
                            atminfo = atmRepo.saveAndFlush(atminfo);

                             if(atminfo != null) {
AtmInfoVO atmvo = new AtmInfoVO();
atmMapper.fromAtmToAtmVO(atminfo, atmvo);
           

arp.setStatus("success");

arp.setBody("ATM added successfully");



                             } else {

                                             

                                            

                                             arp.setStatus("falied");

                                             arp.setBody("Something went wrong in the id. Please check the URL");

                                             return arp;

                             }

                            

             }

             return arp;

}

            

             else {

            	 AtmResponsePattern arp1 = new AtmResponsePattern();

            	 arp1.setStatus("failed");

            	 arp1.setBody("Unable to add ATM");

                             return arp1;

                            

                            

             }



	}

	

	@Override
	public List<AtmInfo> getAtmByCity(Long cityId) {


        
if(cityId != null) {
        List<AtmInfo> atmList = atmRepo.findBycities_cityId(cityId);

        if(atmList != null) {

                                    return   atmList;

        } else {
        	return null;
        }

                       

                       

        } else {

                  

                        return null;

                       

        }

     //   return null;
	}

}
