package com.atm.ing.service;

import java.util.List;

import com.atm.ing.entity.AtmInfo;
import com.atm.ing.responsePattern.AtmResponsePattern;
import com.atm.ing.vo.AtmInfoVO;



public interface AtmService {

public List<AtmInfoVO> getAllAtms();
	
	public AtmResponsePattern addAtm(AtmInfoVO atmVo, Long id);
	
	//public AtmInfoVO getByCityId(Long cityId);
	
	public List<AtmInfo> getAtmByCity(Long cityId);
}
