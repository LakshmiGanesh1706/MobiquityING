package com.atm.ing.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atm.ing.Repository.CityRepository;
import com.atm.ing.entity.CityInfo;
import com.atm.ing.mapper.CityInfoMapper;
import com.atm.ing.responsePattern.CityResponsePattern;
import com.atm.ing.vo.CityInfoVO;

@Service
public class CityServiceImpl implements CityService {

@Autowired

    
CityRepository cityRep; 
     

   

    @Autowired

    CityInfoMapper citymapper;
	
	
	@Override
	public List<CityInfoVO> getCities() {

        List<CityInfoVO> cityVOs = new ArrayList<>();

        List<CityInfo> city = cityRep.findAll();

        city.forEach(c ->{

        	CityInfoVO cityVo = new CityInfoVO();

        	citymapper.fromCityToCityVO(c, cityVo);

        	cityVOs.add(cityVo);

                       

        });

       

return cityVOs;
	}

	@Override
	public CityResponsePattern citypat(CityInfoVO cityVO) {
        

        if(cityVO!= null) {

                       

                       

                        Long autocatId = System.currentTimeMillis();

                        cityVO.setCityId(autocatId);

                       

                        CityResponsePattern crp = new CityResponsePattern();

                        CityInfo city = new CityInfo();

                        citymapper.fromCityVOToCity(cityVO, city);

                        city = cityRep.saveAndFlush(city);

                       

                        if(city != null) {

                        	CityInfoVO newCityVO = new CityInfoVO();

                                        crp.setStatus("Success");

                                        crp.setBody("Successfully City is added");
                                        citymapper.fromCityToCityVO(city, newCityVO);

                                        crp.setCity(city);

                                       

                                        }

                        return crp;

                       

        } else {

                       

                        CityResponsePattern crp = new CityResponsePattern();

                        crp.setStatus("Failed");

                        crp.setBody("Unable to add City");

                        return crp;

                       

        }
	}

}
