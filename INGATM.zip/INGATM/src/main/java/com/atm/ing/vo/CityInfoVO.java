package com.atm.ing.vo;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CityInfoVO {

	@JsonProperty("cityId")

    private Long cityId;
	@JsonProperty("cityName")
	private String cityName;
	
	 @JsonIgnore()

     private List<AtmInfoVO> atms = new ArrayList<>();

	

	public Long getCityId() {
		return cityId;
	}

	public void setCityId(Long cityId) {
		this.cityId = cityId;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public List<AtmInfoVO> getAtms() {
		return atms;
	}

	public void setAtms(List<AtmInfoVO> atms) {
		this.atms = atms;
	}
	 
	
}
