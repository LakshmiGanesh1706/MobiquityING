package com.atm.ing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngAtmApplication {

	public static void main(String[] args) {
		SpringApplication.run(IngAtmApplication.class, args);
	}

}
