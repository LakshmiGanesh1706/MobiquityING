package com.atm.ing.responsePattern;

import com.atm.ing.entity.AtmInfo;
import com.atm.ing.entity.CityInfo;

public class AtmResponsePattern {

private String status;
	
	private String body;
	
	

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	
	
	
}
