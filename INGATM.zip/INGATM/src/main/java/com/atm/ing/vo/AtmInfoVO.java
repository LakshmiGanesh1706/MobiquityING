package com.atm.ing.vo;

import com.atm.ing.entity.CityInfo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AtmInfoVO {
	@JsonProperty("atmId")
	private Long atmId;
	@JsonProperty("atmBranch")
	private String atmBranch;
	@JsonProperty("atmAddress")
	private String atmAddress;
	
	 @JsonIgnore()
private CityInfo cities;
	public Long getAtmId() {
		return atmId;
	}
	public void setAtmId(Long atmId) {
		this.atmId = atmId;
	}
	public String getAtmBranch() {
		return atmBranch;
	}
	public void setAtmBranch(String atmBranch) {
		this.atmBranch = atmBranch;
	}
	public String getAtmAddress() {
		return atmAddress;
	}
	public void setAtmAddress(String atmAddress) {
		this.atmAddress = atmAddress;
	}
	
	public CityInfo getCities() {
		return cities;
	}
	public void setCities(CityInfo cityInfo) {
		this.cities = cityInfo;
	}
	@Override
	public String toString() {
		return "AtmInfoVO [atmId=" + atmId + ", atmBranch=" + atmBranch + ", atmAddress=" + atmAddress + ", cities="
				+ cities + "]";
	}
	
}
