package com.atm.ing.mapper;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.atm.ing.entity.CityInfo;
import com.atm.ing.vo.CityInfoVO;

@Component
public class CityInfoMapper {

	public void fromCityToCityVO(CityInfo cit , CityInfoVO citvo) {
		
		try {
			
			BeanUtils.copyProperties(cit,citvo);
			
		} catch(Exception e) {
		
	}


	}

	public void fromCityVOToCity(CityInfoVO citvo,CityInfo cit  ) {
		
		try {
			
			BeanUtils.copyProperties(citvo,cit);
			
		} catch(Exception e) {
		
	}


	}
	
	
	
	
}
