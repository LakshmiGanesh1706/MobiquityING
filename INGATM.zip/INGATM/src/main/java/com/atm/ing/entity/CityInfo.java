package com.atm.ing.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity

@Table(name="city")
public class CityInfo {
	 @Id

     @Column(name="city_id")
	private Long cityId;
	 @Column(name="city_name")
	private String cityName;
	 @OneToMany(mappedBy="cities",fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)

     private List<AtmInfo> atms = new ArrayList<>();

	public Long getCityId() {
		return cityId;
	}
	
	public void setCityId(Long cityId) {
		this.cityId = cityId;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public List<AtmInfo> getAtms() {
		return atms;
	}

	public void setAtms(List<AtmInfo> atms) {
		this.atms = atms;
	}

	@Override
	public String toString() {
		return "CityInfo [cityId=" + cityId + ", cityName=" + cityName + ", atms=" + atms + "]";
	}
	
	
	
}
