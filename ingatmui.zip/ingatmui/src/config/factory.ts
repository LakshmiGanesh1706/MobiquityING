import { Injectable } from '@angular/core';
import { AppConfig } from './app.config';

export function getAppFromConfig(config: AppConfig) { return () => config.load(); }

