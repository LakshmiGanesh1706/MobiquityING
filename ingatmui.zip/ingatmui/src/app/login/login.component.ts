import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationCancel } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
  }

navigateToSignUpPage() {

this.router.navigateByUrl('/signup');

}

nextPage(){
  this.router.navigateByUrl('/landing');  
}

}
