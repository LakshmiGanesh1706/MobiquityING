import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationCancel } from '@angular/router';
import {AtmListServices} from '../services/atmList.services.component';
@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {
public atmsList: any;
public getCities: any;
  constructor(private router: Router, private route: ActivatedRoute,
    private atmListService : AtmListServices) { }

  ngOnInit() {
this.atmListService.getCities().then(data=>{
  this.getCities = data;
  
}).catch(error => {});


this.atmListService.getAllCities().then(
    data=>{
      this.atmsList = data;
      console.log(data);
    }).catch(error => {});


// this.atmListService.listATMs(cityId).then(
//   data=>{
//     this.atmsList = data;
//   }).catch(error => {});
   
  
  }


  listATMs(){

  }

}
