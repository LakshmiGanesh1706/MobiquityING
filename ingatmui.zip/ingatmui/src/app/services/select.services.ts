
import { AppConfig } from 'src/config/app.config';
import { Http, Response, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Injectable } from '@angular/core';
import { REQUEST_HEADER, META_URL } from 'src/common/common.constants';
import { PRODUCT_CODE, HEADER } from 'src/common/common.constants'
import { DatePipe } from '@angular/common';
//import * as _moment from 'moment';
import { HttpClient } from '@angular/common/http';
//const moment = (_moment as any).default ? (_moment as any).default : _moment;
@Injectable()
export class SelectService {
  hostUrl: string = this.config.getConfig('metaDataHost');
  constructor(
    //private http: Http,
    private httpClient: HttpClient,
    //private datePipe: DatePipe,
    private config: AppConfig) {

  }

  fetchLookUpData(metaDataName: String, params: any) {
    const requestOptions = new RequestOptions(REQUEST_HEADER);
    const request: Object = new Object();
    const url = this.hostUrl + 'uimetadata/fetchmetadata/' +
      metaDataName + (params ? ('/' + params) : '');
    return this.httpClient.get(url, { headers: HEADER })
      .toPromise()
      .then((response: Response) => response)
      .catch(this.handleError);

  }


  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    console.log('ERROR');
    return Promise.reject(error.message || error);
  }
}
