import { Component, OnInit,Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import {REQUEST_HEADER} from '../../constants/constants';
import {HEADER} from '../../constants/constants';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
@Component({
  selector: 'app-services',

})
@Injectable()
export class AtmListServices implements OnInit {
public url: any = 'http://localhost:8090/';
  constructor(
    private http: HttpClient) { }

  ngOnInit() {
  }
public UserRegInfo(UserReg: Object) {
  // const requestOptions = new RequestOptions(REQUEST_HEADER);
const usrurl = this.url + 'userRegistration/Registration';
return this.http.post(usrurl, UserReg, { headers: HEADER })
.toPromise().then((response: Response) =>{console.log(response);}   ).catch(this.handleError);
}

public listATMs(CityId){
    //const requestOptions = new 
    const url = this.url + 'atms/getAtmList/'+CityId;
    return this.http.get(url, { headers: HEADER })
    // return this.httpclient.get(url, { headers: HEADER })
    .toPromise().then((response: Response) =>{console.log(response);}   ).catch(this.handleError);

}

public getCities(){
  const headers = new HttpHeaders({
    'Content-Type': 'application/json','Access-Control-Allow-Origin': '*'
    , 'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
    'Access-Control-Allow-Headers': 'Content-Type'
 });
 let options = {
  headers: headers
}
  const requestOptions = new HttpHeaders();
    const url = this.url + 'city/all';
    return this.http.get(url, options)
    //return this.httpclient.get(url, { headers: HEADER })
    .toPromise().then((response: Response) =>{console.log(response);}   ).catch(this.handleError);
}

public getAllCities(){
  const headers = new HttpHeaders({
    'Content-Type': 'application/json'
 });
 let options = {
  headers: headers
}
 // const requestOptions = new HttpHeaders(REQUEST_HEADER);
    const url1 =  "https://www.ing.nl/api/locator/atms/";
    return this.http.get(url1,options)
    //return this.httpclient.get(url, { headers: HEADER })
    .toPromise().then((response: Response) =>{console.log(response);}   ).catch(this.handleError);
}

/** GET heroes from the server */


// getHeroes(): Observable<Hero[]> {
//     const url = this.url + 'city/all';
//     return this.http.get<Hero[]>(url)
//   }

private handleError(error: any): Promise<any> {
  console.error('An error occurred', error);
  console.log('ERROR' + error);
  return Promise.reject(error.message || error);
}
}
