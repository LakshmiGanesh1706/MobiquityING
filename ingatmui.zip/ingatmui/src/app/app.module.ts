import { routing } from './app-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { TextboxComponent } from './textbox/textbox.component';
import {UserRegServicesComponent} from './services/UserReg.services.component';
import {LandingComponent} from './landing//landing.component';
import {SelectService} from './services/select.services';
import {SelectComponent} from './select/select-component';
import { AppConfig } from 'src/config/app.config';
import {AtmListServices} from './services/atmList.services.component';
//import { HttpModule } from '@angular/http';
//import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http'; 
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    TextboxComponent,
    LandingComponent,
    SelectComponent



  ],
  imports: [
    BrowserModule,
    routing,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    HttpClientModule
  ],
  providers: [UserRegServicesComponent,
    SelectService,
    AppConfig,
    AtmListServices
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
