import { OnInit, EventEmitter, Output, OnChanges } from '@angular/core';
import {
  Component,
  Optional,
  Inject,
  Input,
  ViewChild,
} from '@angular/core';


import {
  NgModel,
  NG_VALUE_ACCESSOR,
  NG_VALIDATORS,
  NG_ASYNC_VALIDATORS,
} from '@angular/forms';
import { ElementBase } from 'src/accessor/element.base';
import { SelectService } from '../services/select.services';
//import { BENIFICIARY_SELF } from 'src/common/common.constants';

@Component({
  selector: 'app-select',
  templateUrl: './select.html',
  //  animations,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: SelectComponent,
    multi: true,
  }],
})
export class SelectComponent extends ElementBase<String> implements OnInit, OnChanges {
  @Input() public label: String;
  @Input() public params: any;
  @Input() public placeholder: String;
  @Input() public lookupName: String;
  @Input() public required: boolean;
  @Input() public DataArray: Array<Object>;
  @Input() public readonly: any = false;
  @Input() public labelhidden: boolean;
  @Output() public changeevent = new EventEmitter<Object>();
  @Input()
  public validationMessage;
  public othersFlag: Boolean = false;

  public results: any;
  @ViewChild(NgModel) model: NgModel;

  public identifier = `app-select${identifier++}`;

  public undefinedValue = undefined;
  constructor(
    @Optional() @Inject(NG_VALIDATORS) validators: Array<any>,
    @Optional() @Inject(NG_ASYNC_VALIDATORS) asyncValidators: Array<any>,

    private selectService: SelectService
  ) {
    super(validators, asyncValidators);
  }
  ngOnInit() {
    if (this.lookupName) {
      this.fetchLookUpdata(this.lookupName);
    }
  }

  ngOnChanges(changes: any) {
    if (this.lookupName) {
      this.fetchLookUpdata(this.lookupName);
    }
  }

  fetchLookUpdata(lookupName: any) {
    if (lookupName) {
      this.selectService.fetchLookUpData(lookupName, this.params)
        .then(data => {
          this.DataArray = data;
        })
        .catch(err => {
          console.log('Error' + err);
        });
    }

  }
  public onBlurMethod(showError: any): boolean {
    if (showError) {
      this.validationMessage = '';
    }
    if ((this.required ) && (this.value === undefined || this.value === null || !this.value)) {
      if (showError) {
        this.validationMessage = (this.label + ' is required');
      }
      // if (this.value === 'Others') {
      //   this.othersFlag = true;
      // }
      return false;
    }
    return true;
  }
  public onBlurOutSideMethod(showError: any): boolean {
    if (showError) {
      this.validationMessage = '';
    }
    if ((this.required ) && (this.value === undefined || this.value === null || !this.value)) {
      if (showError) {
        this.validationMessage = (this.label + ' is required');
      }
      // if (this.value === 'Others') {
      //   this.othersFlag = true;
      // }
      return false;
    }
    return true;
  }

  public onChangeMethod(data: any) {
    this.changeevent.emit(data);
  }


}
let identifier = 0;

