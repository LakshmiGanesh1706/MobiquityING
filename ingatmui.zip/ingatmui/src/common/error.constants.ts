export const INVALID_CHILD: String = 'Child age should be less than Adult age';
export const INVAlID_DATE: String = 'Invalid date selection';
export const INVALID_CHILD_AGE: String = 'Child age should not be equal to Adult age';
export const QUESTION_ERROR_MESSAGE: String = 'If any of the Medical and Lifestyle related information is answered as Yes,' +
    ' then Proposal will require Company referral';
export const PINCODE_ERROR: String = 'Enter valid pincode';
