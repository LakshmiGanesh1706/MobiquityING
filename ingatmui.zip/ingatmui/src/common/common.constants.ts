import { Headers } from '@angular/http';
import { HttpHeaders } from '@angular/common/http';
export const MAIN_PAGE_PART_URL = '/welcome/(contentBody:';
export const META_URL = 'uimetadata/fetchmetadata';
export const LOGIN_URL = '/login';
export const LANDING: String = 'landing';
export const BENIFICIARY_SELF: String = 'Self';
export const BENIFICIARY_SPOUSE: String = 'Spouse';
export const GENDER_MALE: String = 'Male';
export const GENDER_FEMALE: String = 'Female';
export const RELATIONSHIP_DEPENDENT_DAUGHTER: String = 'Dependent daughter';
export const RELATIONSHIP_DEPENDENT_SON: String = 'Dependent son';
export const PRODUCT_CODE: any = 'productcode';
export const PLAN_TYPE_DESC: any = 'planTypeName';
export const PLAN_TYPE_ID: any = 'planid';
export const POLICY_TYPE_DESC: any = 'policyTypeName';
export const SUMISURED: any = 'sumInsured';
export const SUMINSURED_ID = 'sumInsuredId';
export const POLICY_TYPE_ID: any = 'policytypeId';
export const GENDER_ID = 'genderId';
export const GENDER_DESC = 'genderName';
export const RELATION_SHIP_ID: any = 'relationId';
export const RELATION_SHIP_DESC: any = 'relationType';
export const LABEL_GENDER: String = 'Gender';
export const LABEL_RELATIONSHIP: String = 'Relationship';
export const YEAR: String = 'YYYY';
export const DATE: String = 'DD';
export const MONTH: String = 'MM';
export const CODE: any = 'Code';
export const DESCRIPTION: any = 'Description';
export const AFFINITY_SELECTION: String = 'affinity';

export const DEFAULT_POLICY_TYPE = 'Individual';

export const JOB_STATUS = 'jobs';
export const EDITOR_PATH = 'service/getServiceMetaData';
export const UPDATE_JOB_STATUS = 'jobsupdate';
export const DELTER_JOB_STATUS = 'jobsdelete';
export const JOB_PARAMS = 'jobsByParams';
export const USER_PROFILE = 'USER_PROFILE';
export const REQUEST_HEADER = {
    headers: new Headers({
        'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'
        , 'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT'
        , 'Access-Control-Expose-Headers': 'jsontoken'
    })
};

export const HEADER: HttpHeaders = new HttpHeaders()
    .set('Content-Type', 'application/json')
    .set('Access-Control-Allow-Origin', '*')
    .set('Access-Control-Allow-Methods', 'POST, GET, OPTIONS, DELETE, PUT')
    .set('Access-Control-Expose-Headers', 'jsontoken');



export const MY_CUSTOM_FORMATS = {
    parseInput: 'LL LT',
    fullPickerInput: 'DD/MM/YYYY  HH:mm:ss',
    datePickerInput: 'DD/MM/YYYY  HH:mm:ss',
    timePickerInput: 'LT',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
};
